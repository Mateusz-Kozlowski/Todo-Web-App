import './App.css';
import TodoApp from './components/todo/TodoApp';

function App() {
  return (
    <div className="App">
      <TodoApp />
    </div>
  );
}

function FirstComponent() {
  return (
    <div className="FirstComponent">FirstComponent</div>
  )
}

export default App;
